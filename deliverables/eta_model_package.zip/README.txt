Last-mile ETA trained model package

The joblib artifact includes fitted preprocessing and estimator steps. Install the included requirements, then load eta_model.joblib with joblib.load(). Verify compatible Python/scikit-learn versions from manifest.json. The original training CSV is not included.
